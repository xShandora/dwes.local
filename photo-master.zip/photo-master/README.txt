########## PLEASE READ CAREFULLY ###########

This template is the creative and honest work of its author, Penoel Koukou.
It is distributed by BeauxThemes.com under a written and documented 
contract between the author and the owners of BeauxThemes.com

BeauxThemes.com and the author hold the copyright to this template.
That being said, you do not have the right to sell it or distribute in any way
without the written consents of the author and the owners of BeauxThemes.

You can, however, use it for your own website or your client's website if you are a 
web developer. You are allowed to use the template on only ONE website.

The pictures and resources used in the design of this template are the properties of 
their respective owners.


######### CONTACT #########
http://beauxthemes.com/contact